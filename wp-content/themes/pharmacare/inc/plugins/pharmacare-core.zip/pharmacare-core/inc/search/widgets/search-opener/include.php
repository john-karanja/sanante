<?php

include_once PHARMACARE_CORE_INC_PATH . '/search/widgets/search-opener/class-pharmacarecore-search-opener.php';
