<?php

include_once PHARMACARE_CORE_INC_PATH . '/icons/ionicons/class-pharmacarecore-ionicons-pack.php';
