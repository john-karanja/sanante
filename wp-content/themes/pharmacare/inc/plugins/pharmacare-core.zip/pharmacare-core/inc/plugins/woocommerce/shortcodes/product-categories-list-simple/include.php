<?php

include_once PHARMACARE_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-categories-list-simple/product-categories-list-simple.php';