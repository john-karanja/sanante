<?php

include_once PHARMACARE_CORE_INC_PATH . '/header/scroll-appearance/fixed/helper.php';
