(function ( $ ) {
	'use strict';

	qodefCore.shortcodes.pharmacare_core_testimonials_list             = {};
	qodefCore.shortcodes.pharmacare_core_testimonials_list.qodefSwiper = qodef.qodefSwiper;

})( jQuery );
