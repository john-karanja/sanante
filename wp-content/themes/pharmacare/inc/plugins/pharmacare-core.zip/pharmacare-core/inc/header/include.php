<?php

include_once PHARMACARE_CORE_INC_PATH . '/header/helper.php';
include_once PHARMACARE_CORE_INC_PATH . '/header/class-pharmacarecore-header.php';
include_once PHARMACARE_CORE_INC_PATH . '/header/class-pharmacarecore-headers.php';
include_once PHARMACARE_CORE_INC_PATH . '/header/template-functions.php';
