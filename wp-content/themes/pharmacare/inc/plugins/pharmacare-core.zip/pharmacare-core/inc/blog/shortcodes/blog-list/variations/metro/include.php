<?php

include_once PHARMACARE_CORE_INC_PATH . '/blog/shortcodes/blog-list/variations/metro/metro.php';
