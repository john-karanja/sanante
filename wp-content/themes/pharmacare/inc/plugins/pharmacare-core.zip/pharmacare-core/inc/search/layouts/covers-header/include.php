<?php

include_once PHARMACARE_CORE_INC_PATH . '/search/layouts/covers-header/helper.php';
include_once PHARMACARE_CORE_INC_PATH . '/search/layouts/covers-header/class-pharmacarecore-covers-header-search.php';
