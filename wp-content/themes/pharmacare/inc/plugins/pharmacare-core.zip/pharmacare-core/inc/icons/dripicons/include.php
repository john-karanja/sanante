<?php

include_once PHARMACARE_CORE_INC_PATH . '/icons/dripicons/class-pharmacarecore-dripicons-pack.php';
