<?php

include_once PHARMACARE_CORE_INC_PATH . '/mobile-header/helper.php';
include_once PHARMACARE_CORE_INC_PATH . '/mobile-header/class-pharmacarecore-mobile-header.php';
include_once PHARMACARE_CORE_INC_PATH . '/mobile-header/class-pharmacarecore-mobile-headers.php';
include_once PHARMACARE_CORE_INC_PATH . '/mobile-header/template-functions.php';
