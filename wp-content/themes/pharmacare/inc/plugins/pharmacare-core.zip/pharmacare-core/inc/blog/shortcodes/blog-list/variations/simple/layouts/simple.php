<article <?php post_class( $item_classes ); ?>>
	<div class="qodef-e-inner">
		<?php pharmacare_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/image', '', $params ); ?>
		<div class="qodef-e-content">
			<?php pharmacare_core_template_part( 'blog/shortcodes/blog-list', 'templates/post-info/title', '', $params ); ?>
		</div>
	</div>
</article>
