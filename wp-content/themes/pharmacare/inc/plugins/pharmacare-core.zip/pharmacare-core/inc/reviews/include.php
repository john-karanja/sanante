<?php

include_once PHARMACARE_CORE_INC_PATH . '/reviews/helper.php';

