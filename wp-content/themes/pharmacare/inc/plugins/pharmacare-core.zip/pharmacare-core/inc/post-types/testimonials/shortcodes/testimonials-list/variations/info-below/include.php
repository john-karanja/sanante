<?php

include_once PHARMACARE_CORE_CPT_PATH . '/testimonials/shortcodes/testimonials-list/variations/info-below/info-below.php';
