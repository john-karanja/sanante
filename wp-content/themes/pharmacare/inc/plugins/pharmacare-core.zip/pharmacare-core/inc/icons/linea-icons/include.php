<?php

include_once PHARMACARE_CORE_INC_PATH . '/icons/linea-icons/class-pharmacarecore-linea-icons-pack.php';
