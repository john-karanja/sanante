<?php

include_once PHARMACARE_CORE_INC_PATH . '/icons/simple-line-icons/class-pharmacarecore-simple-line-icons-pack.php';
