<?php

include_once PHARMACARE_CORE_INC_PATH . '/media/helper.php';
