<?php

include_once PHARMACARE_CORE_CPT_PATH . '/class-pharmacarecore-custom-post-types.php';
