<div class="qodef-product-list-layouts">
    <ul>
        <li>
            <a class="qodef-layout-grid" href="javascript:void(0)">
                <?php echo qode_framework_icons()->render_icon( 'fa fa-th', 'font-awesome', array( 'icon_attributes' => array( 'class' => '' ) ) ); ?>
            </a>
        </li>
        <li>
            <a class="qodef-layout-list" href="javascript:void(0)">
                <?php echo qode_framework_icons()->render_icon( 'fa fa-list', 'font-awesome', array( 'icon_attributes' => array( 'class' => '' ) ) ); ?>
            </a>
        </li>
    </ul>
</div>