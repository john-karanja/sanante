<?php

include_once PHARMACARE_CORE_INC_PATH . '/icons/pharmacy-icons/class-pharmacarecore-pharmacy-pack.php';