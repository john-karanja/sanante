<?php

include_once PHARMACARE_CORE_CPT_PATH . '/testimonials/shortcodes/testimonials-list/variations/testimonials-carousel-vertical/testimonials-carousel-vertical.php';
