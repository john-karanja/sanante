<?php

include_once PHARMACARE_CORE_INC_PATH . '/blog/shortcodes/blog-list/widget/class-pharmacarecore-blog-list-widget.php';
