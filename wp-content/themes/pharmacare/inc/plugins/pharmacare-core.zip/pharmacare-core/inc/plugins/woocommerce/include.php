<?php

include_once PHARMACARE_CORE_PLUGINS_PATH . '/woocommerce/woocommerce.php';