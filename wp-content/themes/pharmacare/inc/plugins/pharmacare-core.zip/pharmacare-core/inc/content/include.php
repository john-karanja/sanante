<?php

include_once PHARMACARE_CORE_INC_PATH . '/content/helper.php';
