<?php

include_once PHARMACARE_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/widget/class-pharmacarecore-instagram-list-widget.php';
