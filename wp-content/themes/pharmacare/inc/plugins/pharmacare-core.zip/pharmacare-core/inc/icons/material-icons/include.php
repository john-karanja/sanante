<?php

include_once PHARMACARE_CORE_INC_PATH . '/icons/material-icons/class-pharmacarecore-material-icons-pack.php';
