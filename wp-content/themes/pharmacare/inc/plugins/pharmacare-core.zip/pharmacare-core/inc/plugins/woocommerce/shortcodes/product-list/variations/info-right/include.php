<?php

include_once PHARMACARE_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-list/variations/info-right/info-right.php';