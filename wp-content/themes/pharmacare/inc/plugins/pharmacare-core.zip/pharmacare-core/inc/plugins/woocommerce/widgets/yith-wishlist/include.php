<?php

if ( qode_framework_is_installed( 'yith-wishlist' ) ) {
    include_once PHARMACARE_CORE_PLUGINS_PATH . '/woocommerce/widgets/yith-wishlist/yith-wishlist.php';
    include_once PHARMACARE_CORE_PLUGINS_PATH . '/woocommerce/widgets/yith-wishlist/helper.php';
}