<?php

include_once PHARMACARE_CORE_PLUGINS_PATH . '/woocommerce/shortcodes/product-categories-list-simple/widget/class-pharmacarecore-product-categories-list-simple-widget.php';
