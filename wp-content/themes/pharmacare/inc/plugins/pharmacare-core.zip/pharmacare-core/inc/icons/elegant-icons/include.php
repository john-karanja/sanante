<?php

include_once PHARMACARE_CORE_INC_PATH . '/icons/elegant-icons/class-pharmacarecore-elegant-icons-pack.php';
