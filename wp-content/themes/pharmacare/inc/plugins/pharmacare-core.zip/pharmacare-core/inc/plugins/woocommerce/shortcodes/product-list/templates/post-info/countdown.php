<?php

do_action( 'pharmacare_core_action_woo_yith_countdown_on_list' );