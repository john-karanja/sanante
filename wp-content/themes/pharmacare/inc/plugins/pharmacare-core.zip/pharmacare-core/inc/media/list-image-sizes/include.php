<?php

include_once PHARMACARE_CORE_INC_PATH . '/media/list-image-sizes/list-image-sizes.php';
