<?php

include_once PHARMACARE_CORE_PLUGINS_PATH . '/instagram/helper.php';
