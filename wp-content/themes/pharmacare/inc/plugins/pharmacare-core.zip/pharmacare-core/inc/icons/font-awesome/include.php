<?php

include_once PHARMACARE_CORE_INC_PATH . '/icons/font-awesome/class-pharmacarecore-font-awesome-pack.php';
