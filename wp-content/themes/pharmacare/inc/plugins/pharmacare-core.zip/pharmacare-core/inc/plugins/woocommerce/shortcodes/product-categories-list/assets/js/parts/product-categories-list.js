(function ($) {
    "use strict";
    
	qodefCore.shortcodes.pharmacare_core_product_categories_list = {};
	qodefCore.shortcodes.pharmacare_core_product_categories_list.qodefMasonryLayout = qodef.qodefMasonryLayout;
	qodefCore.shortcodes.pharmacare_core_product_categories_list.qodefSwiper = qodef.qodefSwiper;

})(jQuery);