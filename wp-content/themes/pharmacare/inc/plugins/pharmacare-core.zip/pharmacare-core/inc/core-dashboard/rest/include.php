<?php

include_once PHARMACARE_CORE_INC_PATH . '/core-dashboard/rest/rest.php';