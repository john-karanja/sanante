<?php

include_once PHARMACARE_CORE_PLUGINS_PATH . '/woocommerce/widgets/dropdown-cart/dropdown-cart.php';