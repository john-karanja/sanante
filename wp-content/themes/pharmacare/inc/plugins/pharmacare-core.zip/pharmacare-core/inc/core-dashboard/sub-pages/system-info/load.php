<?php

include_once PHARMACARE_CORE_INC_PATH . '/core-dashboard/sub-pages/system-info/system-info.php';