<?php

include_once PHARMACARE_CORE_INC_PATH . '/icons/linear-icons/class-pharmacarecore-linear-icons-pack.php';
