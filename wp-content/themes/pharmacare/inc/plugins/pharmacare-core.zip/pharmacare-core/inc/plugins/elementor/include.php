<?php

if ( qode_framework_is_installed( 'elementor' ) ) {
	include_once PHARMACARE_CORE_PLUGINS_PATH . '/elementor/helper.php';
	include_once PHARMACARE_CORE_PLUGINS_PATH . '/elementor/class-pharmacarecore-elementor-section-handler.php';
}
