<?php

include_once PHARMACARE_CORE_INC_PATH . '/opener-icon/helper.php';
