<?php

include_once PHARMACARE_CORE_PLUGINS_PATH . '/woocommerce/modules/products-filter/helper.php';
